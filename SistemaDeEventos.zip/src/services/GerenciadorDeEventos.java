package services;

import models.Evento;
import models.Usuario;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class GerenciadorDeEventos {
    private List<Evento> eventos;
    private List<Usuario> usuarios;
    private static final String FILE_NAME = "events.data";

    public GerenciadorDeEventos() {
        this.eventos = new ArrayList<>();
        this.usuarios = new ArrayList<>();
        carregarEventos();
    }

    public void cadastrarUsuario(String nome, String email, String cidade) {
        usuarios.add(new Usuario(nome, email, cidade));
    }

    public Usuario buscarUsuarioPorEmail(String email) {
        for (Usuario u : usuarios) {
            if (u.getEmail().equalsIgnoreCase(email)) {
                return u;
            }
        }
        return null;
    }

    public void cadastrarEvento(String nome, String endereco, String categoria, LocalDateTime horario, String descricao) {
        eventos.add(new Evento(nome, endereco, categoria, horario, descricao));
        salvarEventos();
    }

    public List<Evento> listarEventosOrdenados() {
        return eventos.stream()
                .sorted(Comparator.comparing(Evento::getHorario))
                .collect(Collectors.toList());
    }

    public void participarDoEvento(Evento evento, Usuario usuario) {
        evento.adicionarParticipante(usuario);
        salvarEventos();
    }

    public void cancelarParticipacao(Evento evento, Usuario usuario) {
        evento.removerParticipante(usuario);
        salvarEventos();
    }

    public List<Evento> eventosDoUsuario(Usuario usuario) {
        return eventos.stream()
                .filter(e -> e.getParticipantes().contains(usuario))
                .collect(Collectors.toList());
    }

    public List<Evento> eventosOcorrendoAgora() {
        LocalDateTime agora = LocalDateTime.now();
        return eventos.stream()
                .filter(e -> e.getHorario().isBefore(agora.plusMinutes(1)) && e.getHorario().isAfter(agora.minusMinutes(60)))
                .collect(Collectors.toList());
    }

    public List<Evento> eventosJaOcorreram() {
        LocalDateTime agora = LocalDateTime.now();
        return eventos.stream()
                .filter(e -> e.getHorario().isBefore(agora))
                .collect(Collectors.toList());
    }

    private void salvarEventos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(eventos);
        } catch (IOException e) {
            System.out.println("Erro ao salvar eventos: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void carregarEventos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            eventos = (List<Evento>) ois.readObject();
        } catch (FileNotFoundException e) {
            eventos = new ArrayList<>();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Erro ao carregar eventos: " + e.getMessage());
            eventos = new ArrayList<>();
        }
    }
}