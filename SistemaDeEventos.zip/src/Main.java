import models.Evento;
import models.Usuario;
import services.GerenciadorDeEventos;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static GerenciadorDeEventos gerenciador = new GerenciadorDeEventos();
    private static Scanner scanner = new Scanner(System.in);
    private static Usuario usuarioLogado;

    public static void main(String[] args) {
        System.out.println("=== Sistema de Eventos ===");

        login();

        int opcao;
        do {
            menu();
            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1 -> cadastrarEvento();
                case 2 -> listarEventos();
                case 3 -> participarDeEvento();
                case 4 -> cancelarParticipacao();
                case 5 -> listarMeusEventos();
                case 6 -> eventosOcorrendoAgora();
                case 7 -> eventosJaOcorreram();
                case 0 -> System.out.println("Saindo...");
                default -> System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }

    private static void login() {
        System.out.print("Informe seu email para login ou cadastro: ");
        String email = scanner.nextLine();

        usuarioLogado = gerenciador.buscarUsuarioPorEmail(email);
        if (usuarioLogado == null) {
            System.out.println("Novo usuário! Informe seus dados:");
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Cidade: ");
            String cidade = scanner.nextLine();

            gerenciador.cadastrarUsuario(nome, email, cidade);
            usuarioLogado = gerenciador.buscarUsuarioPorEmail(email);
        }
        System.out.println("Bem-vindo, " + usuarioLogado.getNome() + "!");
    }

    private static void menu() {
        System.out.println("\n=== Menu ===");
        System.out.println("1 - Cadastrar Evento");
        System.out.println("2 - Listar Eventos");
        System.out.println("3 - Participar de Evento");
        System.out.println("4 - Cancelar Participação");
        System.out.println("5 - Meus Eventos");
        System.out.println("6 - Eventos Ocorrendo Agora");
        System.out.println("7 - Eventos que Já Ocorreram");
        System.out.println("0 - Sair");
        System.out.print("Escolha: ");
    }

    private static void cadastrarEvento() {
        System.out.println("Cadastro de Evento:");
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();
        System.out.print("Categoria (Show, Festa, Esportivo, etc.): ");
        String categoria = scanner.nextLine();
        System.out.print("Data e hora (formato: yyyy-MM-dd HH:mm): ");
        String dataHora = scanner.nextLine();
        LocalDateTime horario = LocalDateTime.parse(dataHora, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        System.out.print("Descrição: ");
        String descricao = scanner.nextLine();

        gerenciador.cadastrarEvento(nome, endereco, categoria, horario, descricao);
        System.out.println("Evento cadastrado com sucesso!");
    }

    private static void listarEventos() {
        List<Evento> eventos = gerenciador.listarEventosOrdenados();
        System.out.println("\n=== Lista de Eventos ===");
        eventos.forEach(System.out::println);
    }

    private static void participarDeEvento() {
        listarEventos();
        System.out.print("Informe o nome do evento para participar: ");
        String nomeEvento = scanner.nextLine();

        Evento evento = gerenciador.listarEventosOrdenados().stream()
                .filter(e -> e.getNome().equalsIgnoreCase(nomeEvento))
                .findFirst()
                .orElse(null);

        if (evento != null) {
            gerenciador.participarDoEvento(evento, usuarioLogado);
            System.out.println("Participação confirmada!");
        } else {
            System.out.println("Evento não encontrado.");
        }
    }

    private static void cancelarParticipacao() {
        listarMeusEventos();
        System.out.print("Informe o nome do evento para cancelar participação: ");
        String nomeEvento = scanner.nextLine();

        Evento evento = gerenciador.eventosDoUsuario(usuarioLogado).stream()
                .filter(e -> e.getNome().equalsIgnoreCase(nomeEvento))
                .findFirst()
                .orElse(null);

        if (evento != null) {
            gerenciador.cancelarParticipacao(evento, usuarioLogado);
            System.out.println("Participação cancelada!");
        } else {
            System.out.println("Evento não encontrado.");
        }
    }

    private static void listarMeusEventos() {
        List<Evento> meusEventos = gerenciador.eventosDoUsuario(usuarioLogado);
        System.out.println("\n=== Meus Eventos ===");
        meusEventos.forEach(System.out::println);
    }

    private static void eventosOcorrendoAgora() {
        List<Evento> eventos = gerenciador.eventosOcorrendoAgora();
        System.out.println("\n=== Eventos Ocorrendo Agora ===");
        eventos.forEach(System.out::println);
    }

    private static void eventosJaOcorreram() {
        List<Evento> eventos = gerenciador.eventosJaOcorreram();
        System.out.println("\n=== Eventos que Já Ocorreram ===");
        eventos.forEach(System.out::println);
    }
}